# POORCRAFT 3D — the walkable build (NWR-003 surface spike, 2026-09-07)

Windowed 3D game over the deterministic simulation, original glTF assets,
and now the natural-terrain surface spike. Deterministic per seed.

## Play the world (first person)
  ./poorcraft3d --play-slice live
WASD walk, click to look, F places / R removes at your aim, B saves,
L reloads, I shows Bed/Work/Idle boxes, Esc quits.

## Automated windowed proofs
  ./poorcraft3d --play-surface     # NEW: natural-terrain spike + edit
  ./poorcraft3d --play-assets      # original GLB tree/rock/house
  ./poorcraft3d --play-slice | --play-city | --play-npcs
  ./poorcraft3d --play-water | --play-terrain | --play-stream
  ./poorcraft3d --play-quality | --play-shot | --play
(PNGs land in a shots/ folder next to the binary.)

## Windowless simulation
  --journey 4242 | --diagnose 2024 | --soak 365 80808
  --atlas 2024 24 | --flow-map 2024 | --validate-assets
