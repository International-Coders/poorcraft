# POORCRAFT 3D — the walkable build (NWR-001 baseline, 2026-09-07)

POORCRAFT 3D now has a real windowed 3D game on top of its deterministic
simulation: first-person walking with terrain collision, caves, rivers,
city, NPCs, building, and save/reload — proven by a 9-gate windowed
regression battery. Everything below is deterministic per seed.

## Play the world (first person)
  ./poorcraft3d --play-slice live
WASD walk, click to look, F places / R removes a block at your aim point,
B saves, L reloads, I shows the Bed/Work/Idle boxes, Esc quits.
(Same seed every launch: showcase seed 22.)

## Watch the automated proofs (each opens a window)
  ./poorcraft3d --play-slice          # the vertical slice showcase (3 shots)
  ./poorcraft3d --play-city           # castle + town + the gate close-up
  ./poorcraft3d --play-npcs           # resident/worker/guard + inspect boxes
  ./poorcraft3d --play-water          # river + a dam edit mid-run
  ./poorcraft3d --play-terrain        # hill / cliff / cave+overhang scenes
  ./poorcraft3d --play-stream         # streamed LOD walk, 3 waypoints
  ./poorcraft3d --play-quality        # the same scene at Low/Mid/High
  ./poorcraft3d --play-shot           # camera/depth/parallax proof
  ./poorcraft3d --play                # free flight (no collision)
(PNGs land in a shots/ folder next to the binary.)

## The living simulation (windowless, deterministic)
  ./poorcraft3d --journey 4242        # a full player life, 10 asserted steps
  ./poorcraft3d --diagnose 2024       # 13 system checks + proof PNGs
  ./poorcraft3d --soak 365 80808      # one in-game year, audited
  ./poorcraft3d --atlas 2024 24       # biome atlas | --flow-map 2024 rivers
  ./poorcraft3d --validate-assets     # the beta-critical asset manifest
