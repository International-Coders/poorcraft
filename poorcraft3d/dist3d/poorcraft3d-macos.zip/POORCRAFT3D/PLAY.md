# POORCRAFT 3D — the walkable build (NWR-002 asset factory, 2026-09-07)

POORCRAFT 3D has a real windowed 3D game on top of its deterministic
simulation, and now loads ORIGINAL glTF assets (tree, rock, croft house).
Everything is deterministic per seed.

## Play the world (first person)
  ./poorcraft3d --play-slice live
WASD walk, click to look, F places / R removes a block at your aim point,
B saves, L reloads, I shows the Bed/Work/Idle boxes, Esc quits.

## Watch the automated proofs (each opens a window)
  ./poorcraft3d --play-assets         # NEW: original GLB tree/rock/house
  ./poorcraft3d --play-slice          # the vertical slice showcase
  ./poorcraft3d --play-city           # castle + town + the gate
  ./poorcraft3d --play-npcs           # resident/worker/guard + boxes
  ./poorcraft3d --play-water          # river + a dam edit mid-run
  ./poorcraft3d --play-terrain        # hill / cliff / cave scenes
  ./poorcraft3d --play-stream         # streamed LOD walk
  ./poorcraft3d --play-quality        # Low/Mid/High tiers
  ./poorcraft3d --play-shot           # camera/depth/parallax proof
(PNGs land in a shots/ folder next to the binary.)

## The living simulation (windowless, deterministic)
  ./poorcraft3d --journey 4242        # a full player life, 10 steps
  ./poorcraft3d --diagnose 2024       # 13 system checks + PNGs
  ./poorcraft3d --soak 365 80808      # one in-game year, audited
  ./poorcraft3d --validate-assets     # asset manifest gate
